package com.example.cryptoanalyzer

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { AnalyzerApp() } }
    }
}

data class Candle(val time: Long, val open: Double, val high: Double, val low: Double, val close: Double, val volume: Double)
data class IndicatorRow(val timeframe: String, val price: Double, val emas: Map<Int, Double>, val obv: Double, val macd: Double, val signal: Double, val hist: Double, val upProbability: Int, val downProbability: Int, val support: Double, val resistance: Double, val setup: String)

private val client = OkHttpClient()
private fun getJson(url: String): JSONObject {
    val request = Request.Builder().url(url).get().build()
    client.newCall(request).execute().use { response ->
        if (!response.isSuccessful) throw Exception("Bitget HTTP ${response.code}")
        return JSONObject(response.body?.string() ?: "{}")
    }
}
private fun parseCandles(root: JSONObject): List<Candle> {
    val data = root.optJSONArray("data") ?: JSONArray()
    val result = mutableListOf<Candle>()
    for (i in 0 until data.length()) {
        val a = data.optJSONArray(i) ?: continue
        if (a.length() < 6) continue
        result.add(Candle(a.optString(0).toLongOrNull() ?: 0L, a.optString(1).toDoubleOrNull() ?: 0.0, a.optString(2).toDoubleOrNull() ?: 0.0, a.optString(3).toDoubleOrNull() ?: 0.0, a.optString(4).toDoubleOrNull() ?: 0.0, a.optString(5).toDoubleOrNull() ?: 0.0))
    }
    return result.filter { it.close > 0.0 }.sortedBy { it.time }
}
private fun ema(values: List<Double>, period: Int): Double {
    if (values.isEmpty()) return 0.0
    val alpha = 2.0 / (period + 1.0)
    var result = values.take(min(period, values.size)).average()
    for (v in values.drop(min(period, values.size))) result = alpha * v + (1 - alpha) * result
    return result
}
private fun analyze(candles: List<Candle>, tf: String): IndicatorRow {
    val closes = candles.map { it.close }
    val price = closes.last()
    val emas = listOf(9,14,21,50,100,200).associateWith { ema(closes, it) }
    var obv = 0.0
    for (i in 1 until candles.size) obv += when { candles[i].close > candles[i-1].close -> candles[i].volume; candles[i].close < candles[i-1].close -> -candles[i].volume; else -> 0.0 }
    val macdSeries = mutableListOf<Double>()
    for (i in closes.indices) macdSeries.add(ema(closes.take(i + 1), 12) - ema(closes.take(i + 1), 26))
    val macd = macdSeries.lastOrNull() ?: 0.0
    val signal = ema(macdSeries, 9)
    val hist = macd - signal
    val votes = (if (price > emas.getValue(9)) 1 else -1) + (if (price > emas.getValue(21)) 1 else -1) + (if (price > emas.getValue(50)) 1 else -1) + (if (emas.getValue(9) > emas.getValue(21)) 1 else -1) + (if (hist > 0) 1 else -1) + (if (obv > 0) 1 else -1)
    val up = (50 + votes * 7).coerceIn(8, 92)
    val lows = candles.takeLast(30).map { it.low }
    val highs = candles.takeLast(30).map { it.high }
    val support = lows.minOrNull() ?: price
    val resistance = highs.maxOrNull() ?: price
    val setup = when {
        price > emas.getValue(50) && hist > 0 -> "Bullish bias; wait for a pullback/retest before considering LONG or Spot entry."
        price < emas.getValue(50) && hist < 0 -> "Bearish bias; SHORT only after confirmation; avoid chasing a drop."
        else -> "Mixed signals; wait for a confirmed breakout or support rejection."
    }
    return IndicatorRow(tf, price, emas, obv, macd, signal, hist, up, 100-up, support, resistance, setup)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnalyzerApp() {
    var symbol by remember { mutableStateOf("BTCUSDT") }
    var market by remember { mutableStateOf("Spot") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var price by remember { mutableStateOf<Double?>(null) }
    var rows by remember { mutableStateOf<List<IndicatorRow>>(emptyList()) }
    var backtest by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val tfMap = listOf("1H" to "1H", "4H" to "4H", "1D" to "1D")

    fun runAnalysis() {
        val clean = symbol.trim().uppercase().replace("/", "").replace("-", "")
        if (!clean.matches(Regex("[A-Z0-9]{5,24}"))) { error = "Enter a valid market symbol, e.g. BTCUSDT"; return }
        symbol = clean
        loading = true; error = ""; rows = emptyList(); backtest = ""
        scope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    val isSpot = market == "Spot"
                    val tickerUrl = if (isSpot) "https://api.bitget.com/api/v2/spot/market/tickers?symbol=$clean" else "https://api.bitget.com/api/v2/mix/market/ticker?productType=USDT-FUTURES&symbol=$clean"
                    val tickerRoot = getJson(tickerUrl)
                    val tickerData = tickerRoot.optJSONArray("data")
                    val ticker = if (tickerData != null && tickerData.length() > 0) tickerData.optJSONObject(0) ?: JSONObject() else tickerRoot.optJSONObject("data") ?: JSONObject()
                    val currentPrice = ticker.optString("lastPr", ticker.optString("last", "")).toDoubleOrNull() ?: 0.0
                    val analyzed = mutableListOf<IndicatorRow>()
                    val candleSets = mutableListOf<Pair<String, List<Candle>>>()
                    for ((label, granularity) in tfMap) {
                        val candleUrl = if (isSpot) "https://api.bitget.com/api/v2/spot/market/candles?symbol=$clean&granularity=$granularity&limit=200" else "https://api.bitget.com/api/v2/mix/market/candles?symbol=$clean&granularity=$granularity&productType=USDT-FUTURES&limit=200"
                        val candles = parseCandles(getJson(candleUrl))
                        if (candles.size < 30) throw Exception("Not enough candle history for $label. Check symbol and market availability.")
                        candleSets.add(label to candles)
                        analyzed.add(analyze(candles, label))
                    }
                    val hourly = candleSets.first().second
                    // Simple educational EMA(9)/EMA(21) crossover backtest, one position at a time, close-to-close, fees excluded.
                    var cash = 1.0; var held = false; var entry = 0.0; var trades = 0; var wins = 0
                    for (i in 25 until hourly.size) {
                        val cs = hourly.take(i + 1).map { it.close }
                        val fast = ema(cs, 9); val slow = ema(cs, 21); val prevFast = ema(cs.dropLast(1), 9); val prevSlow = ema(cs.dropLast(1), 21)
                        if (!held && prevFast <= prevSlow && fast > slow) { held = true; entry = hourly[i].close }
                        else if (held && prevFast >= prevSlow && fast < slow) { val r = hourly[i].close / entry; cash *= r; trades++; if (r > 1) wins++; held = false }
                    }
                    if (held) { val r = hourly.last().close / entry; cash *= r; trades++; if (r > 1) wins++ }
                    Triple(currentPrice, analyzed, "EMA 9/21 crossover on 1H · ${hourly.size} candles · $trades closed trades · return ${(cash - 1) * 100.0}% · win rate ${if (trades > 0) wins * 100 / trades else 0}% (fees/slippage excluded; not a forecast).")
                }
                price = result.first.takeIf { it > 0.0 }; rows = result.second; backtest = result.third
                if (price == null) error = "Candles loaded, but Bitget did not return a usable ticker price."
            } catch (e: Exception) { error = e.message ?: "Could not load market data. Check your connection and Bitget symbol." }
            finally { loading = false }
        }
    }

    Scaffold(topBar = { TopAppBar(title = { Text("Bitget Crypto Analyzer", fontWeight = FontWeight.Bold) }) }) { padding ->
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(vertical = 12.dp)) {
            item { Text("Market analysis · English", style = MaterialTheme.typography.bodyMedium) }
            item { OutlinedTextField(value = symbol, onValueChange = { symbol = it.uppercase() }, label = { Text("Coin / market symbol") }, placeholder = { Text("e.g. AIAVUSDT") }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = market == "Spot", onClick = { market = "Spot" }, label = { Text("Spot") })
                    FilterChip(selected = market == "Futures", onClick = { market = "Futures" }, label = { Text("USDT Futures") })
                    Spacer(Modifier.weight(1f))
                    Button(onClick = { runAnalysis() }, enabled = !loading) { Text(if (loading) "Loading…" else "Analyze") }
                }
            }
            if (loading) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
            if (error.isNotBlank()) item { Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) { Text(error, Modifier.padding(12.dp), color = MaterialTheme.colorScheme.onErrorContainer) } }
            if (price != null) item {
                Card { Column(Modifier.padding(16.dp)) {
                    Text("${symbol} · $market", style = MaterialTheme.typography.titleMedium)
                    Text("${price}", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                    Text("Live market data from Bitget public API", style = MaterialTheme.typography.bodySmall)
                } }
            }
            if (rows.isNotEmpty()) {
                item { Text("Technical indicators", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
                items(rows) { r ->
                    Card { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Text("${r.timeframe} timeframe", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("Price: ${fmt(r.price)}")
                        Column(Modifier.horizontalScroll(rememberScrollState())) {
                            r.emas.forEach { (period, value) -> Text("EMA $period: ${fmt(value)}  ${if (r.price >= value) "· Price above" else "· Price below"}") }
                        }
                        Divider()
                        Text("OBV: ${fmt(r.obv)}")
                        Text("MACD: ${fmt(r.macd)} · Signal: ${fmt(r.signal)} · Histogram: ${fmt(r.hist)}")
                        Text("Heuristic directional score: ${r.upProbability}% bullish / ${r.downProbability}% bearish", fontWeight = FontWeight.SemiBold)
                        Text("Recent support: ${fmt(r.support)}")
                        Text("Recent resistance: ${fmt(r.resistance)}")
                        Text(r.setup)
                    } }
                }
                item { Card { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Backtest (educational)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(backtest)
                    Text("This is a simple baseline, not a validated strategy. It does not model fees, slippage, funding, liquidation or position sizing.", style = MaterialTheme.typography.bodySmall)
                } } }
                item { Card { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Project & investor research", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("This first version does not automatically verify a project's investors, partnerships, token unlocks or fundamentals. Use primary sources and mark claims as verified, unverified or unknown.")
                    Text("Search project / investors", color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 4.dp))
                    Text("https://www.google.com/search?q=${symbol}+crypto+investors+funding+official")
                } } }
            }
            item { Text("Risk notice: Indicator scores are rule-based heuristics, NOT statistically calibrated probabilities. They are not a guarantee of future returns. Futures trading can result in rapid loss of capital. Never trade from this screen alone.", style = MaterialTheme.typography.bodySmall) }
            item { Text("Data access: public Bitget market endpoints only. No API key, account connection, or order execution is included.", style = MaterialTheme.typography.bodySmall) }
        }
    }
}
private fun fmt(v: Double): String = if (!v.isFinite()) "—" else String.format(java.util.Locale.US, "%.8f", v).trimEnd('0').trimEnd('.')
