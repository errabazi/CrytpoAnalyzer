# Bitget Crypto Analyzer (Android MVP)

English-language Android starter app using Kotlin + Jetpack Compose and Bitget public market APIs.

## Current MVP features
- Symbol input, e.g. `BTCUSDT` or `AIAVUSDT`
- Spot and USDT-margined Futures market selection
- Latest price from Bitget public ticker endpoint
- 1H, 4H, 1D candles and EMA 9/14/21/50/100/200, OBV, MACD, signal and histogram
- Recent 30-candle low/high as support/resistance references
- Rule-based bullish/bearish directional score (explicitly NOT a calibrated probability)
- Simple 1H EMA 9/21 crossover historical baseline backtest
- Risk disclaimer and project/investor research prompt

## Build
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Open this folder in Android Studio and allow Gradle sync.
3. Run on an Android device/emulator with internet access.
4. To create an APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Important limitations
- This is source code for an MVP, not a prebuilt APK. It has not been compiled or tested on a device in this environment.
- Bitget public endpoint availability and symbol formats may vary; API errors are shown in the app.
- OBV is cumulative over the downloaded candle window; its absolute value depends on that window.
- Directional scores are simple rule-based heuristics, not measured probabilities. Do not interpret them as reliable odds.
- Backtest ignores fees, slippage, futures funding, liquidation, sizing, and realistic execution. It is only a baseline demonstration.
- Project/funding/investor research is not yet automated; the app provides a search starting point and should not assert unverified claims.
- No order placement, API keys, exchange account access, or financial advice is implemented.
