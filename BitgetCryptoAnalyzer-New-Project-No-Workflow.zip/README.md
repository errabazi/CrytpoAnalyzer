# Bitget Crypto Analyzer

Android application project built with Kotlin and Jetpack Compose.

## Project structure

- `app/` — Android application source and resources
- `build.gradle.kts` — root Gradle build configuration
- `settings.gradle.kts` — Gradle project settings
- `gradle.properties` — Gradle properties

## Build

Open this folder in Android Studio, allow Gradle sync to finish, then select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

The Java and Kotlin JVM targets are both configured to Java 17.

This package intentionally does not include a GitHub Actions workflow. You can upload these project files to a new repository without adding a workflow file.
